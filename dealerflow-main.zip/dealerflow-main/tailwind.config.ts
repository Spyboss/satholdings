import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/app/**/*.{ts,tsx}", "./src/components/**/*.{ts,tsx}", "./src/lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        canvas: "#f5f4ef",
        ink: "#1c1a17",
        accent: {
          red: "#c32026",
          rust: "#9a1d1f",
        },
      },
      boxShadow: {
        panel: "0 14px 28px rgba(35, 33, 29, 0.08)",
      },
    },
  },
  plugins: [],
};

export default config;
