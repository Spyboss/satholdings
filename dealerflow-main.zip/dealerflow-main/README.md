# DealerFlow MVP - Build Start

This repository now includes the first implementation pass for the SBK Tyre Distributors wholesale portal based on:

- the stakeholder WhatsApp discovery chat,
- the provided tyre price list sample,
- the logo/reference screenshots,
- and the PRD + architecture docs under `docs/`.

## What Is Implemented In This Pass

- Next.js App Router project scaffold with TypeScript + Tailwind
- Cloudflare OpenNext adapter setup (`open-next.config.ts`, `wrangler.jsonc`)
- Mobile-first public catalog page with tyre size/brand search
- Guest price masking and authenticated role price visibility
- Temporary role switch flow (for rapid local prototyping before Supabase auth wiring)
- Initial API routes:
  - `GET /api/v1/auth/me`
  - `GET /api/v1/catalog/products`
  - `GET /api/v1/catalog/filters/sizes`
- Seeded sample catalog data from the supplied November 2025 trade list
- Drizzle schema foundation aligned to docs data dictionary (`src/db/schema.ts`)

## Quick Start

Use Node.js 20+ for Cloudflare + Supabase toolchain compatibility.

1. Install dependencies:

   ```bash
   npm install
   ```

2. Copy and fill env values:

   ```bash
   cp .env.example .env.local
   ```

3. Start local dev server:

   ```bash
   npm run dev
   ```

4. Open:

   - `http://localhost:3000/`
   - `http://localhost:3000/catalog`
   - `http://localhost:3000/login`

## Cloudflare Runtime Notes

Recent Cloudflare docs recommend full-stack Next.js deployments on Workers using OpenNext. This build follows that path and includes the required Worker adapter configuration for preview/deploy scripts.

## Security Reminder

The original chat export included credentials. Rotate every shared credential before staging or production use.
