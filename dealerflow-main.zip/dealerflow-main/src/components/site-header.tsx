import Link from "next/link";
import { getSessionRole, roleLabel } from "@/lib/auth/session";

const roleSwitches = [
  { role: "guest", label: "Guest" },
  { role: "dealer", label: "Dealer" },
  { role: "staff", label: "Staff" },
  { role: "admin", label: "Admin" },
] as const;

export async function SiteHeader() {
  const currentRole = await getSessionRole();

  return (
    <header className="sticky top-0 z-20 border-b border-[#d5d0c3] bg-[#f9f7f1]/95 backdrop-blur">
      <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <div className="rounded-md bg-gradient-to-r from-[#d3272d] to-[#851417] px-2 py-1 text-xs font-bold tracking-[0.1em] text-white">
            SBK
          </div>
          <div>
            <p className="text-sm font-semibold leading-none">DealerFlow</p>
            <p className="text-xs text-[#5f5a4f]">Wholesale Tyre Portal</p>
          </div>
        </div>

        <nav className="hidden items-center gap-4 text-sm font-medium text-[#4c473d] md:flex">
          <Link className="transition hover:text-[#b21f24]" href="/">
            Home
          </Link>
          <Link className="transition hover:text-[#b21f24]" href="/catalog">
            Catalog
          </Link>
          <Link className="transition hover:text-[#b21f24]" href="/login">
            Login Demo
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <span className="hidden rounded-full border border-[#d9d2c4] bg-white px-3 py-1 text-xs font-semibold text-[#4f4a3f] sm:inline-flex">
            {roleLabel(currentRole)} View
          </span>
          <div className="hidden items-center gap-1 lg:flex">
            {roleSwitches.map((entry) => {
              const href = `/auth/switch?role=${entry.role}&next=/catalog`;
              const isActive = currentRole === entry.role;

              return (
                <Link
                  key={entry.role}
                  className={`rounded-md px-2 py-1 text-xs font-semibold transition ${
                    isActive
                      ? "bg-[#1f1a16] text-white"
                      : "bg-white text-[#4d473f] ring-1 ring-[#ddd6c8] hover:bg-[#f2eee4]"
                  }`}
                  href={href}
                >
                  {entry.label}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
}
