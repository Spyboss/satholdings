import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  date,
  index,
  inet,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export const roleEnum = pgEnum("role", ["admin", "staff", "dealer"]);
export const accountStatusEnum = pgEnum("account_status", ["active", "inactive"]);
export const fulfillmentEnum = pgEnum("fulfillment_method", ["pickup", "delivery"]);
export const orderStatusEnum = pgEnum("order_status", [
  "pending",
  "confirmed",
  "packed",
  "ready",
  "dispatched",
  "completed",
  "cancelled",
]);
export const priceListStatusEnum = pgEnum("price_list_status", ["draft", "active", "archived"]);
export const movementTypeEnum = pgEnum("movement_type", ["in", "out", "adjust"]);
export const invoiceStatusEnum = pgEnum("invoice_status", ["draft", "issued", "void"]);

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    authUserId: uuid("auth_user_id").notNull(),
    email: text("email").notNull(),
    fullName: text("full_name"),
    role: roleEnum("role").notNull(),
    status: accountStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    authUserIdUnique: uniqueIndex("users_auth_user_id_ux").on(table.authUserId),
    emailUnique: uniqueIndex("users_email_ux").on(table.email),
    roleIdx: index("users_role_idx").on(table.role),
    statusIdx: index("users_status_idx").on(table.status),
  }),
);

export const dealerProfiles = pgTable(
  "dealer_profiles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    companyName: text("company_name").notNull(),
    abn: text("abn"),
    phone: text("phone"),
    addressLine1: text("address_line1"),
    addressLine2: text("address_line2"),
    city: text("city"),
    state: text("state"),
    postcode: text("postcode"),
    country: text("country").notNull().default("AU"),
    defaultFulfillment: fulfillmentEnum("default_fulfillment"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    userUnique: uniqueIndex("dealer_profiles_user_ux").on(table.userId),
  }),
);

export const products = pgTable(
  "products",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    sku: text("sku").notNull(),
    brand: text("brand").notNull(),
    model: text("model"),
    size: text("size").notNull(),
    loadRating: text("load_rating"),
    speedRating: text("speed_rating"),
    pattern: text("pattern"),
    description: text("description"),
    imagePath: text("image_path"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    skuUnique: uniqueIndex("products_sku_ux").on(table.sku),
    brandIdx: index("products_brand_idx").on(table.brand),
    sizeIdx: index("products_size_idx").on(table.size),
  }),
);

export const inventory = pgTable(
  "inventory",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    locationCode: text("location_code").notNull().default("MAIN"),
    onHand: integer("on_hand").notNull().default(0),
    reserved: integer("reserved").notNull().default(0),
    reorderLevel: integer("reorder_level").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    productLocationUnique: uniqueIndex("inventory_product_location_ux").on(table.productId, table.locationCode),
  }),
);

export const priceLists = pgTable("price_lists", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  currency: text("currency").notNull().default("AUD"),
  effectiveFrom: date("effective_from").notNull(),
  effectiveTo: date("effective_to"),
  status: priceListStatusEnum("status").notNull().default("draft"),
  createdBy: uuid("created_by").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const priceListItems = pgTable(
  "price_list_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    priceListId: uuid("price_list_id")
      .notNull()
      .references(() => priceLists.id, { onDelete: "cascade" }),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
    gstInclusive: boolean("gst_inclusive").notNull().default(true),
    minQty: integer("min_qty").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    uniquePricingTier: uniqueIndex("price_list_items_pricing_tier_ux").on(table.priceListId, table.productId, table.minQty),
  }),
);

export const orders = pgTable(
  "orders",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    orderNumber: text("order_number").notNull(),
    dealerUserId: uuid("dealer_user_id")
      .notNull()
      .references(() => users.id),
    dealerProfileId: uuid("dealer_profile_id")
      .notNull()
      .references(() => dealerProfiles.id),
    status: orderStatusEnum("status").notNull().default("pending"),
    fulfillmentMethod: fulfillmentEnum("fulfillment_method").notNull(),
    deliveryAddress: jsonb("delivery_address").$type<Record<string, string | null> | null>(),
    notes: text("notes"),
    subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull().default("0"),
    gstTotal: numeric("gst_total", { precision: 12, scale: 2 }).notNull().default("0"),
    grandTotal: numeric("grand_total", { precision: 12, scale: 2 }).notNull().default("0"),
    requestedAt: timestamp("requested_at", { withTimezone: true }).notNull().defaultNow(),
    confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    orderNumberUnique: uniqueIndex("orders_order_number_ux").on(table.orderNumber),
    dealerIdx: index("orders_dealer_user_idx").on(table.dealerUserId),
    statusIdx: index("orders_status_idx").on(table.status),
    createdAtIdx: index("orders_created_at_idx").on(table.createdAt),
  }),
);

export const orderItems = pgTable(
  "order_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    orderId: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id),
    skuSnapshot: text("sku_snapshot").notNull(),
    sizeSnapshot: text("size_snapshot").notNull(),
    brandSnapshot: text("brand_snapshot").notNull(),
    unitPriceSnapshot: numeric("unit_price_snapshot", { precision: 10, scale: 2 }).notNull(),
    quantity: integer("quantity").notNull(),
    lineTotal: numeric("line_total", { precision: 12, scale: 2 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    orderIdx: index("order_items_order_idx").on(table.orderId),
    productIdx: index("order_items_product_idx").on(table.productId),
  }),
);

export const stockMovements = pgTable(
  "stock_movements",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id),
    orderItemId: uuid("order_item_id").references(() => orderItems.id),
    movementType: movementTypeEnum("movement_type").notNull(),
    quantity: integer("quantity").notNull(),
    reasonCode: text("reason_code").notNull(),
    referenceType: text("reference_type").notNull(),
    referenceId: uuid("reference_id"),
    performedBy: uuid("performed_by").references(() => users.id),
    performedAt: timestamp("performed_at", { withTimezone: true }).notNull().defaultNow(),
    notes: text("notes"),
  },
  (table) => ({
    productPerformedIdx: index("stock_movements_product_performed_idx").on(table.productId, table.performedAt),
    orderItemIdx: index("stock_movements_order_item_idx").on(table.orderItemId),
  }),
);

export const invoices = pgTable(
  "invoices",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    orderId: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    invoiceNumber: text("invoice_number").notNull(),
    status: invoiceStatusEnum("status").notNull().default("draft"),
    filePath: text("file_path").notNull(),
    fileSizeBytes: bigint("file_size_bytes", { mode: "number" }),
    generatedAt: timestamp("generated_at", { withTimezone: true }).notNull().defaultNow(),
    generatedBy: uuid("generated_by").references(() => users.id),
  },
  (table) => ({
    orderUnique: uniqueIndex("invoices_order_ux").on(table.orderId),
    invoiceNumberUnique: uniqueIndex("invoices_invoice_number_ux").on(table.invoiceNumber),
  }),
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    actorUserId: uuid("actor_user_id").references(() => users.id),
    action: text("action").notNull(),
    entityType: text("entity_type").notNull(),
    entityId: uuid("entity_id"),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
    ipAddress: inet("ip_address"),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    actorIdx: index("audit_logs_actor_idx").on(table.actorUserId),
    entityIdx: index("audit_logs_entity_idx").on(table.entityType, table.entityId),
    createdAtIdx: index("audit_logs_created_at_idx").on(table.createdAt),
  }),
);

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
