import { NextRequest, NextResponse } from "next/server";
import { ROLE_COOKIE_NAME, isAppRole } from "@/lib/auth/session";

const thirtyDaysInSeconds = 60 * 60 * 24 * 30;

export function GET(request: NextRequest) {
  const roleParam = request.nextUrl.searchParams.get("role");
  const nextParam = request.nextUrl.searchParams.get("next");
  const role = isAppRole(roleParam) ? roleParam : "guest";
  const nextPath = nextParam?.startsWith("/") ? nextParam : "/catalog";

  const response = NextResponse.redirect(new URL(nextPath, request.url));
  response.cookies.set({
    name: ROLE_COOKIE_NAME,
    value: role,
    path: "/",
    maxAge: thirtyDaysInSeconds,
    sameSite: "lax",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
  });

  return response;
}
