import Link from "next/link";
import { getSessionRole, roleLabel } from "@/lib/auth/session";

const roles = [
  {
    id: "guest",
    title: "Guest",
    description: "Browse catalog only, no prices, no ordering.",
  },
  {
    id: "dealer",
    title: "Dealer",
    description: "See trade prices and order stock.",
  },
  {
    id: "staff",
    title: "Staff",
    description: "Operational access for stock and order processing.",
  },
  {
    id: "admin",
    title: "Admin",
    description: "Full control including user and pricing management.",
  },
] as const;

export default async function LoginPage() {
  const currentRole = await getSessionRole();

  return (
    <section className="space-y-6">
      <div className="rounded-3xl border border-[#ddd6c8] bg-white p-6 shadow-panel">
        <p className="text-xs font-semibold uppercase tracking-[0.09em] text-[#7a7468]">Prototype Auth</p>
        <h1 className="mt-2 text-3xl font-extrabold text-[#221d18]">Session Role Switcher</h1>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-[#5e584d]">
          This temporary switcher is used while Supabase authentication and manual dealer provisioning flows are being
          wired in the next phase.
        </p>

        <p className="mt-4 inline-flex rounded-full border border-[#d9d2c4] bg-[#f8f4ea] px-3 py-1 text-sm font-semibold text-[#463f34]">
          Active role: {roleLabel(currentRole)}
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {roles.map((role) => {
          const href = `/auth/switch?role=${role.id}&next=/catalog`;
          const isCurrent = currentRole === role.id;

          return (
            <article key={role.id} className="rounded-2xl border border-[#ddd6c8] bg-white p-5 shadow-panel">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-[#211c17]">{role.title}</h2>
                {isCurrent ? (
                  <span className="rounded-full bg-[#1f1a16] px-2 py-1 text-xs font-semibold text-white">Current</span>
                ) : null}
              </div>

              <p className="mt-2 text-sm leading-6 text-[#565145]">{role.description}</p>

              <Link
                className="mt-4 inline-flex rounded-lg bg-[#c32026] px-3 py-2 text-sm font-semibold text-white transition hover:bg-[#9a1d1f]"
                href={href}
              >
                Continue as {role.title}
              </Link>
            </article>
          );
        })}
      </div>

      <Link
        className="inline-flex rounded-lg border border-[#d8d2c4] bg-white px-3 py-2 text-sm font-semibold text-[#403a31] transition hover:bg-[#f2eee3]"
        href="/auth/logout?next=/"
      >
        Clear Session
      </Link>
    </section>
  );
}
