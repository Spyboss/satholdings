import { NextRequest } from "next/server";
import { ROLE_COOKIE_NAME, canPlaceOrder, canViewTradePrices, resolveRole } from "@/lib/auth/session";
import { createRequestId, success } from "@/lib/api/envelope";

export function GET(request: NextRequest) {
  const requestId = createRequestId();
  const role = resolveRole(request.cookies.get(ROLE_COOKIE_NAME)?.value);

  return success(
    {
      role,
      status: role === "guest" ? "anonymous" : "active",
      capabilities: {
        canViewTradePrices: canViewTradePrices(role),
        canPlaceOrder: canPlaceOrder(role),
      },
    },
    requestId,
  );
}
