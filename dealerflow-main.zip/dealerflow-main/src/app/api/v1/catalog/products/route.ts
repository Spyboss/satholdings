import { NextRequest } from "next/server";
import { createRequestId, failure, success } from "@/lib/api/envelope";
import { ROLE_COOKIE_NAME, resolveRole } from "@/lib/auth/session";
import { listCatalogProducts } from "@/lib/catalog/catalog";
import { catalogQuerySchema } from "@/lib/validation/catalog";

export function GET(request: NextRequest) {
  const requestId = createRequestId();
  const params = request.nextUrl.searchParams;

  const parsed = catalogQuerySchema.safeParse({
    search: params.get("search") ?? undefined,
    brand: params.get("brand") ?? undefined,
    size: params.get("size") ?? undefined,
    page: params.get("page") ?? undefined,
    pageSize: params.get("pageSize") ?? undefined,
  });

  if (!parsed.success) {
    return failure(requestId, "BAD_REQUEST", "Invalid catalog query parameters.", 400, parsed.error.flatten());
  }

  const role = resolveRole(request.cookies.get(ROLE_COOKIE_NAME)?.value);
  const result = listCatalogProducts(parsed.data, role);

  return success(result, requestId);
}
