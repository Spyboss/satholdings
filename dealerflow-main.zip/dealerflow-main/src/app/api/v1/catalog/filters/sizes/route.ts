import { NextRequest } from "next/server";
import { createRequestId, success } from "@/lib/api/envelope";
import { listCatalogSizes } from "@/lib/catalog/catalog";

export function GET(request: NextRequest) {
  const requestId = createRequestId();
  const search = request.nextUrl.searchParams.get("search") ?? undefined;

  return success(
    {
      sizes: listCatalogSizes(search),
    },
    requestId,
  );
}
