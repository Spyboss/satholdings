import clsx from "clsx";
import Link from "next/link";
import { canViewTradePrices, getSessionRole, roleLabel } from "@/lib/auth/session";
import { listCatalogProducts } from "@/lib/catalog/catalog";
import { stockLabel } from "@/lib/catalog/stock";
import { catalogQuerySchema } from "@/lib/validation/catalog";

export const dynamic = "force-dynamic";

type CatalogPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

function asSingle(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) {
    return value[0];
  }

  return value;
}

function buildPageLink(params: URLSearchParams, page: number): string {
  const nextParams = new URLSearchParams(params.toString());
  nextParams.set("page", String(page));
  return `/catalog?${nextParams.toString()}`;
}

function stockChipClass(stockState: "in_stock" | "low_stock" | "out_of_stock"): string {
  if (stockState === "in_stock") {
    return "bg-emerald-50 text-emerald-700 border-emerald-200";
  }

  if (stockState === "low_stock") {
    return "bg-amber-50 text-amber-700 border-amber-200";
  }

  return "bg-zinc-100 text-zinc-700 border-zinc-300";
}

export default async function CatalogPage({ searchParams }: CatalogPageProps) {
  const params = await searchParams;
  const role = await getSessionRole();

  const parsed = catalogQuerySchema.safeParse({
    search: asSingle(params.search),
    brand: asSingle(params.brand),
    size: asSingle(params.size),
    page: asSingle(params.page),
    pageSize: asSingle(params.pageSize),
  });

  const query = parsed.success
    ? parsed.data
    : {
        page: 1,
        pageSize: 20,
      };

  const result = listCatalogProducts(query, role);

  const browserParams = new URLSearchParams();
  if (query.search) {
    browserParams.set("search", query.search);
  }
  if (query.brand) {
    browserParams.set("brand", query.brand);
  }
  if (query.size) {
    browserParams.set("size", query.size);
  }
  browserParams.set("pageSize", String(query.pageSize));

  const canSeePrices = canViewTradePrices(role);

  return (
    <section className="space-y-6">
      <div className="rounded-3xl border border-[#ddd6c8] bg-white p-6 shadow-panel">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.09em] text-[#7c7569]">Catalog</p>
            <h1 className="mt-1 text-3xl font-extrabold text-[#221d18]">Tyre Price List</h1>
            <p className="mt-2 text-sm text-[#5f594d]">
              Showing {result.total} product{result.total === 1 ? "" : "s"}. Role: {roleLabel(role)}.
            </p>
          </div>

          {!canSeePrices ? (
            <Link
              className="inline-flex rounded-lg bg-[#c32026] px-3 py-2 text-sm font-semibold text-white transition hover:bg-[#991b1f]"
              href="/login"
            >
              Login to view prices
            </Link>
          ) : null}
        </div>

        <form action="/catalog" className="mt-5 grid gap-3 md:grid-cols-4">
          <input
            className="h-11 rounded-lg border border-[#d9d2c4] bg-white px-3 text-sm outline-none ring-[#c32026] transition focus:ring-2"
            defaultValue={query.search ?? ""}
            name="search"
            placeholder="Search size, brand, sku"
          />

          <select
            className="h-11 rounded-lg border border-[#d9d2c4] bg-white px-3 text-sm outline-none ring-[#c32026] transition focus:ring-2"
            defaultValue={query.brand ?? ""}
            name="brand"
          >
            <option value="">All brands</option>
            {result.availableBrands.map((brand) => (
              <option key={brand} value={brand}>
                {brand}
              </option>
            ))}
          </select>

          <select
            className="h-11 rounded-lg border border-[#d9d2c4] bg-white px-3 text-sm outline-none ring-[#c32026] transition focus:ring-2"
            defaultValue={query.size ?? ""}
            name="size"
          >
            <option value="">All sizes</option>
            {result.availableSizes.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>

          <div className="flex gap-2">
            <input name="pageSize" type="hidden" value={query.pageSize} />
            <button
              className="h-11 w-full rounded-lg bg-[#1f1a16] px-4 text-sm font-semibold text-white transition hover:bg-black"
              type="submit"
            >
              Apply Filters
            </button>
            <Link
              className="inline-flex h-11 items-center rounded-lg border border-[#d8d1c3] bg-white px-4 text-sm font-semibold text-[#3f3930] transition hover:bg-[#f2eee3]"
              href="/catalog"
            >
              Reset
            </Link>
          </div>
        </form>
      </div>

      {result.items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[#d5cebf] bg-[#faf8f2] p-8 text-center text-sm text-[#5f594d]">
          No products matched the current filters.
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {result.items.map((item) => (
            <article key={item.id} className="rounded-2xl border border-[#ddd6c8] bg-white p-5 shadow-panel">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[#7a7468]">{item.brand}</p>
                  <h2 className="mt-1 text-2xl font-extrabold text-[#1e1914]">{item.size}</h2>
                  <p className="text-sm text-[#5f594d]">{item.model}</p>
                </div>

                <span className={clsx("rounded-full border px-2 py-1 text-xs font-semibold", stockChipClass(item.stockState))}>
                  {stockLabel(item.stockState)}
                </span>
              </div>

              <div className="mt-4 space-y-2 text-sm text-[#5a5448]">
                <p>SKU: {item.sku}</p>
                <p>Pattern: {item.pattern}</p>
                <p>On hand: {item.onHand}</p>
              </div>

              <div className="mt-5 rounded-xl border border-[#e3dccf] bg-[#faf7ef] p-3">
                {canSeePrices && item.unitPriceAud !== undefined ? (
                  <p className="text-2xl font-extrabold text-[#1f1a15]">AUD ${item.unitPriceAud.toFixed(2)}</p>
                ) : (
                  <p className="text-sm font-semibold text-[#b26a18]">Login to view trade prices</p>
                )}
              </div>

              <button
                className={clsx(
                  "mt-4 w-full rounded-lg px-3 py-2 text-sm font-semibold transition",
                  item.canOrder && canSeePrices
                    ? "bg-[#c32026] text-white hover:bg-[#991b1f]"
                    : "cursor-not-allowed bg-[#efeadf] text-[#877f73]",
                )}
                disabled={!item.canOrder || !canSeePrices}
                type="button"
              >
                {item.canOrder && canSeePrices ? "Add to Cart" : "Ordering unavailable"}
              </button>
            </article>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between rounded-2xl border border-[#ddd6c8] bg-white p-4 shadow-panel">
        <p className="text-sm text-[#5e584d]">
          Page {result.page} of {result.totalPages}
        </p>
        <div className="flex gap-2">
          <Link
            aria-disabled={result.page <= 1}
            className={clsx(
              "rounded-lg border px-3 py-2 text-sm font-semibold",
              result.page <= 1
                ? "pointer-events-none border-[#e4ddcf] bg-[#f5f0e5] text-[#a59d90]"
                : "border-[#d8d1c3] bg-white text-[#3f3930] hover:bg-[#f2eee3]",
            )}
            href={buildPageLink(browserParams, Math.max(1, result.page - 1))}
          >
            Previous
          </Link>
          <Link
            aria-disabled={result.page >= result.totalPages}
            className={clsx(
              "rounded-lg border px-3 py-2 text-sm font-semibold",
              result.page >= result.totalPages
                ? "pointer-events-none border-[#e4ddcf] bg-[#f5f0e5] text-[#a59d90]"
                : "border-[#d8d1c3] bg-white text-[#3f3930] hover:bg-[#f2eee3]",
            )}
            href={buildPageLink(browserParams, Math.min(result.totalPages, result.page + 1))}
          >
            Next
          </Link>
        </div>
      </div>
    </section>
  );
}
