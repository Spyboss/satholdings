import Link from "next/link";

export default function HomePage() {
  return (
    <section className="space-y-8">
      <div className="relative overflow-hidden rounded-3xl border border-[#e0dacd] bg-gradient-to-r from-[#fbf7ee] via-[#f8f2e3] to-[#f5e3dc] p-6 shadow-panel sm:p-10">
        <div className="absolute -right-20 -top-24 h-64 w-64 rounded-full bg-[#d3272d]/10 blur-3xl" />
        <div className="absolute -left-24 -bottom-24 h-64 w-64 rounded-full bg-[#aa1f23]/10 blur-3xl" />

        <div className="relative max-w-3xl space-y-4">
          <p className="inline-flex rounded-full border border-[#e1d9ca] bg-white px-3 py-1 text-xs font-semibold tracking-[0.09em] text-[#6a6458]">
            SBK TYRE DISTRIBUTORS
          </p>
          <h1 className="text-3xl font-extrabold tracking-tight text-[#1e1a17] sm:text-5xl">
            DealerFlow build has started.
          </h1>
          <p className="max-w-2xl text-sm leading-6 text-[#595449] sm:text-base">
            This first implementation pass turns the approved discovery docs into a working baseline: private
            wholesale price visibility, mobile-first catalog search, and Cloudflare-ready runtime setup.
          </p>

          <div className="flex flex-wrap gap-3 pt-2">
            <Link
              className="rounded-xl bg-[#c32026] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#991b1f]"
              href="/catalog"
            >
              Open Catalog
            </Link>
            <Link
              className="rounded-xl border border-[#d8d2c4] bg-white px-4 py-2 text-sm font-semibold text-[#3d372f] transition hover:bg-[#f3efe4]"
              href="/login"
            >
              Switch Role
            </Link>
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <article className="rounded-2xl border border-[#ddd6c8] bg-white p-5 shadow-panel">
          <h2 className="text-xl font-bold text-[#241f19]">Price Privacy</h2>
          <p className="mt-2 text-sm leading-6 text-[#565145]">
            Guests can browse products but cannot see trade prices. Dealer, staff, and admin roles can view pricing.
          </p>
        </article>

        <article className="rounded-2xl border border-[#ddd6c8] bg-white p-5 shadow-panel">
          <h2 className="text-xl font-bold text-[#241f19]">Phone-First Search</h2>
          <p className="mt-2 text-sm leading-6 text-[#565145]">
            Tyre size and brand filtering is optimized for fast lookup on mobile warehouse floors.
          </p>
        </article>

        <article className="rounded-2xl border border-[#ddd6c8] bg-white p-5 shadow-panel">
          <h2 className="text-xl font-bold text-[#241f19]">Cloudflare Ready</h2>
          <p className="mt-2 text-sm leading-6 text-[#565145]">
            Runtime uses OpenNext + Workers adapter setup based on current Cloudflare deployment guidance.
          </p>
        </article>
      </div>
    </section>
  );
}
