import { NextResponse } from "next/server";

export function createRequestId(): string {
  return `req_${crypto.randomUUID().replace(/-/g, "").slice(0, 12)}`;
}

export function success<T>(data: T, requestId: string, status = 200) {
  return NextResponse.json(
    {
      data,
      meta: { requestId },
    },
    { status },
  );
}

export function failure(
  requestId: string,
  code: string,
  message: string,
  status: number,
  details: unknown = null,
) {
  return NextResponse.json(
    {
      error: {
        code,
        message,
        details,
      },
      meta: { requestId },
    },
    { status },
  );
}
