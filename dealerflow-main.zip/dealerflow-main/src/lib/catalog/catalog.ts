import { canPlaceOrder, canViewTradePrices } from "@/lib/auth/session";
import { getStockState } from "@/lib/catalog/stock";
import { productSeed } from "@/lib/data/products";
import type { AppRole, CatalogProductView, CatalogQuery, ProductRecord } from "@/lib/types";

export type CatalogResult = {
  items: CatalogProductView[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  availableBrands: string[];
  availableSizes: string[];
};

function normalizeToken(value: string): string {
  return value.trim().toLowerCase().replace(/\s+/g, " ");
}

function matchesProduct(product: ProductRecord, search: string): boolean {
  const token = normalizeToken(search);

  if (!token) {
    return true;
  }

  const haystack = [product.brand, product.model, product.size, product.pattern, product.sku]
    .join(" ")
    .toLowerCase();

  return haystack.includes(token);
}

function toCatalogView(product: ProductRecord, role: AppRole): CatalogProductView {
  const stockState = getStockState(product.onHand, product.reorderLevel);
  const view: CatalogProductView = {
    id: product.id,
    sku: product.sku,
    brand: product.brand,
    model: product.model,
    size: product.size,
    pattern: product.pattern,
    stockState,
    onHand: product.onHand,
    canOrder: canPlaceOrder(role) && stockState !== "out_of_stock",
  };

  if (canViewTradePrices(role)) {
    view.unitPriceAud = product.unitPriceAud;
  }

  return view;
}

function filterProducts(query: CatalogQuery): ProductRecord[] {
  const search = query.search ? normalizeToken(query.search) : undefined;
  const brand = query.brand ? normalizeToken(query.brand) : undefined;
  const size = query.size ? normalizeToken(query.size) : undefined;

  return productSeed
    .filter((product) => product.isActive)
    .filter((product) => {
      if (brand && normalizeToken(product.brand) !== brand) {
        return false;
      }

      if (size && normalizeToken(product.size) !== size) {
        return false;
      }

      if (search && !matchesProduct(product, search)) {
        return false;
      }

      return true;
    });
}

export function listCatalogProducts(query: CatalogQuery, role: AppRole): CatalogResult {
  const filtered = filterProducts(query);
  const total = filtered.length;
  const totalPages = total === 0 ? 1 : Math.ceil(total / query.pageSize);
  const page = Math.min(query.page, totalPages);
  const start = (page - 1) * query.pageSize;
  const end = start + query.pageSize;

  const items = filtered.slice(start, end).map((product) => toCatalogView(product, role));

  return {
    items,
    total,
    page,
    pageSize: query.pageSize,
    totalPages,
    availableBrands: listCatalogBrands(),
    availableSizes: listCatalogSizes(),
  };
}

export function listCatalogSizes(search?: string): string[] {
  const token = search ? normalizeToken(search) : undefined;

  return [...new Set(productSeed.map((product) => product.size))]
    .filter((size) => {
      if (!token) {
        return true;
      }

      return normalizeToken(size).includes(token);
    })
    .sort((a, b) => a.localeCompare(b));
}

export function listCatalogBrands(): string[] {
  return [...new Set(productSeed.map((product) => product.brand))].sort((a, b) => a.localeCompare(b));
}
