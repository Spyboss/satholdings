import type { StockState } from "@/lib/types";

export function getStockState(onHand: number, reorderLevel: number): StockState {
  if (onHand <= 0) {
    return "out_of_stock";
  }

  if (onHand <= reorderLevel) {
    return "low_stock";
  }

  return "in_stock";
}

export function stockLabel(state: StockState): string {
  switch (state) {
    case "in_stock":
      return "In Stock";
    case "low_stock":
      return "Low Stock";
    default:
      return "Out of Stock";
  }
}
