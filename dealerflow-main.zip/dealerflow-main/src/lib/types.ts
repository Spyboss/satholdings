export const APP_ROLES = ["guest", "dealer", "staff", "admin"] as const;

export type AppRole = (typeof APP_ROLES)[number];

export type StockState = "in_stock" | "low_stock" | "out_of_stock";

export type ProductRecord = {
  id: string;
  sku: string;
  brand: string;
  model: string;
  size: string;
  pattern: string;
  unitPriceAud: number;
  onHand: number;
  reorderLevel: number;
  isActive: boolean;
};

export type CatalogProductView = {
  id: string;
  sku: string;
  brand: string;
  model: string;
  size: string;
  pattern: string;
  stockState: StockState;
  onHand: number;
  canOrder: boolean;
  unitPriceAud?: number;
};

export type CatalogQuery = {
  search?: string;
  brand?: string;
  size?: string;
  page: number;
  pageSize: number;
};
