import { cookies } from "next/headers";
import { APP_ROLES, type AppRole } from "@/lib/types";

export const ROLE_COOKIE_NAME = "df-role";

type CookieStoreLike = {
  get: (name: string) => { value: string } | undefined;
};

export function isAppRole(value: string | null | undefined): value is AppRole {
  if (!value) {
    return false;
  }

  return (APP_ROLES as readonly string[]).includes(value);
}

export function resolveRole(rawRole: string | null | undefined): AppRole {
  if (!isAppRole(rawRole)) {
    return "guest";
  }

  return rawRole;
}

export function getRoleFromCookieStore(cookieStore: CookieStoreLike): AppRole {
  return resolveRole(cookieStore.get(ROLE_COOKIE_NAME)?.value);
}

export async function getSessionRole(): Promise<AppRole> {
  const cookieStore = await cookies();
  return getRoleFromCookieStore(cookieStore);
}

export function canViewTradePrices(role: AppRole): boolean {
  return role !== "guest";
}

export function canPlaceOrder(role: AppRole): boolean {
  return role === "dealer" || role === "admin";
}

export function roleLabel(role: AppRole): string {
  switch (role) {
    case "admin":
      return "Admin";
    case "staff":
      return "Staff";
    case "dealer":
      return "Dealer";
    default:
      return "Guest";
  }
}
