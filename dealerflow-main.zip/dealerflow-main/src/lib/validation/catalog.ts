import { z } from "zod";

const optionalString = z.preprocess(
  (value) => {
    if (typeof value !== "string") {
      return undefined;
    }

    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : undefined;
  },
  z.string().max(64).optional(),
);

export const catalogQuerySchema = z.object({
  search: optionalString,
  brand: optionalString,
  size: optionalString,
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export type CatalogQueryInput = z.infer<typeof catalogQuerySchema>;
