# 03 - Architecture

Version: v1.0
Date: 2026-03-07

## 1) Architecture Goals

- Keep the stack simple and low-maintenance
- Enforce strict wholesale price privacy
- Optimize for mobile dealer workflows
- Maintain auditability for stock and order events
- Support gradual extension (email invoices, payments, analytics)

## 2) High-Level System Diagram

```mermaid
flowchart LR
  U1[Guest Browser]
  U2[Dealer Browser]
  U3[Admin/Staff Browser]

  CF[Cloudflare Workers + OpenNext\nNext.js App Router]
  SBDB[(Supabase Postgres)]
  SBA[Supabase Auth]
  SBS[Supabase Storage]
  SBE[Supabase Edge Functions]

  U1 --> CF
  U2 --> CF
  U3 --> CF

  CF --> SBA
  CF --> SBDB
  CF --> SBS
  CF --> SBE

  SBE --> SBDB
  SBE --> SBS
```

## 3) Core Components

### 3.1 Frontend (Next.js)

- Next.js App Router pages for guest, dealer, admin, and staff experiences
- Tailwind CSS + shadcn/ui component layer
- Mobile-first page templates with touch-friendly actions
- Auth-aware rendering to gate price visibility and ordering actions

### 3.2 API Layer (Route Handlers / Server Actions)

- `/api/v1` route handlers for catalog, orders, inventory, users, invoices
- Zod request/response validation
- Role checks and policy guards on every protected route
- Business transactions for order confirmation and stock deduction

### 3.3 Data Access Layer

- Drizzle ORM for schema, migrations, and typed query access
- Postgres transaction blocks for stock consistency
- Indexed search fields (`size`, `brand`, optional normalized tokens)

### 3.4 Supabase Services

- Auth for identity and session lifecycle
- Postgres as system of record
- Storage for product media and invoice PDFs
- Edge Functions for isolated privileged operations if required

## 4) Runtime Model

- Primary app runtime: Cloudflare Workers with OpenNext adapter
- Server logic executes in Worker runtime context
- Sensitive admin operations use server-side credentials only
- Browser never receives service role keys

## 5) Key Data Flows

### 5.1 Guest Catalog Flow

1. Guest requests product listing
2. API returns public product fields only
3. Price fields are excluded at query/response level

### 5.2 Dealer Login and Order Flow

1. Dealer authenticates via Supabase Auth
2. Session token is validated by server routes
3. Dealer views price-enabled catalog
4. Dealer submits order request with cart lines and fulfillment method
5. Admin/staff confirms order
6. Stock deduction transaction executes and movement logs are recorded

### 5.3 Invoice Generation Flow

1. Eligible order reaches invoice state
2. Server generates PDF payload using `@react-pdf/renderer`
3. PDF stored in protected Supabase Storage bucket
4. Authorized users can download via signed access path

## 6) Data Isolation and Security Design

- Row Level Security (RLS) enabled for all business tables
- Dealer can only read own orders and profile context
- Admin/staff can manage operational entities by role permission
- Guest access restricted to public catalog projection
- Audit logs are append-only to preserve evidence integrity

## 7) Reliability and Consistency

- Stock mutation only through transaction-safe paths
- Concurrency handling with row-level locking on inventory update
- Idempotency key support for order submission to avoid duplicates
- Retry-safe invoice generation with deterministic invoice numbers

## 8) Performance Design

- Indexes: `products(size)`, `products(brand)`, `orders(created_at)`, `order_items(order_id)`
- Pagination on catalog and order history endpoints
- Cached static guest pages where possible
- Keep heavy admin reports async or paginated

## 9) Observability

- Structured application logs (request id, actor id, route, latency)
- Audit log events for privileged actions
- Error tracking pipeline for server/runtime exceptions
- Uptime and synthetic checks for login, catalog, and checkout paths

## 10) Backup and Recovery

- Supabase automated database backups enabled
- Storage bucket backup/export schedule defined in operations runbook
- Recovery drill at least once per quarter

## 11) Architecture Decisions

- AD-001: Use Cloudflare Workers + OpenNext instead of Vercel for hosting
- AD-002: Keep backend services consolidated in Supabase
- AD-003: Disable public signup; admin-managed dealer provisioning only
- AD-004: Start with order request workflow, no payment gateway in v1
- AD-005: Enforce price privacy through DB policy + API + UI layers

## 12) Known Technical Watchouts

- PDF generation library compatibility (`@react-pdf/renderer`) must be validated in Cloudflare runtime early
- If runtime constraints appear, switch invoice rendering to `pdf-lib` in a compatible function path
- Service role usage must be restricted to server-only contexts
