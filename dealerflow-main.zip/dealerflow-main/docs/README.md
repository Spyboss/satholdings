# DealerFlow Documentation

This folder contains the full delivery and implementation documentation for the SBK wholesale tyre portal.

## Project Snapshot

- Product: Private B2B wholesale ordering portal for tyre dealers
- Hosting: Cloudflare Workers + OpenNext adapter
- Backend: Supabase (Postgres, Auth, Storage, Edge Functions)
- Frontend: Next.js App Router + TypeScript + Tailwind CSS + shadcn/ui
- Data access: Drizzle ORM + Zod validation
- Invoice generation: `@react-pdf/renderer` + Supabase Storage
- Billing model in v1: Order request only (no online payment)

## Reading Order

1. `docs/01-PRD.md` - Product requirements and acceptance criteria
2. `docs/02-Full-Plan.md` - End-to-end phased execution plan
3. `docs/03-Architecture.md` - System architecture and technical decisions
4. `docs/04-ERD.md` - Entity relationships and schema model
5. `docs/05-Data-Dictionary.md` - Field-level table definitions
6. `docs/06-API-Spec.md` - API contract definitions
7. `docs/07-RBAC-Security.md` - Roles, permissions, and security controls
8. `docs/08-User-Flows.md` - Guest, dealer, admin, and staff journey maps
9. `docs/09-Test-Plan.md` - QA, UAT, and release verification strategy
10. `docs/10-Deployment-Runbook.md` - Environment setup and production rollout
11. `docs/11-Risks-Assumptions.md` - Risk register, assumptions, and open decisions

## Inputs Used

- Business requirements collected from stakeholder WhatsApp discussions
- Reference portal style and flow from provided screenshot
- Initial product/price sample from supplied tyre price list artwork
- Branding direction from provided SBK logo asset

## Versioning and Change Control

- Document owner: Product + Engineering
- Update cadence: At the end of every phase or when scope changes
- Versioning format: `v<major>.<minor>`
- Major version increments for scope/architecture changes
- Minor version increments for clarifications and wording updates

## Security Reminder

Project artifacts included exposed credentials in shared chat exports. Rotate all previously shared credentials before any staging or production deployment.
