# 08 - User Flows

Version: v1.0
Date: 2026-03-07

## 1) Navigation Map

- Public: Home -> Catalog -> Product Detail -> Login
- Dealer: Dashboard -> Catalog -> Cart -> Checkout -> Order Confirmation -> Order History -> Invoice Download
- Staff/Admin: Admin Dashboard -> Orders -> Inventory -> Products -> Dealers (admin only) -> Audit Logs (admin only)

## 2) Guest Flow (Browse Without Prices)

1. Guest lands on public home page
2. Opens catalog and searches by tyre size or brand
3. Views product cards and details with no pricing shown
4. Attempts order action and is prompted to log in
5. Moves to login page if account exists

UX rules:

- Price area shows `Login to view trade prices`
- Add-to-cart hidden or disabled for guest
- Search must be visible and fast on mobile

## 3) Dealer Flow (Search to Order)

1. Dealer logs in
2. Sees catalog with trade prices enabled
3. Searches tyre size and filters results
4. Adds items to cart and adjusts quantities
5. Enters checkout, selects `Pickup` or `Delivery`
6. Submits order request
7. Receives order number and pending status
8. Tracks status updates from order history
9. Downloads invoice once generated

Validation rules:

- Quantity must be positive integer
- Delivery address required when `Delivery` selected
- Out-of-stock items cannot be submitted without admin override

## 4) Admin Flow (Dealer Onboarding)

1. Admin opens dealer management
2. Creates dealer account with email and company profile
3. System sends initial password setup invitation/reset flow
4. Admin verifies status as active
5. Dealer can now sign in and see prices

Operational controls:

- Admin can deactivate/reactivate dealer
- User role change requires explicit audit log event

## 5) Staff Flow (Order Operations)

1. Staff reviews pending orders queue
2. Validates stock and confirms order
3. System deducts stock and records stock movements
4. Staff moves order through packed/ready/dispatched statuses
5. Staff triggers invoice generation when appropriate

Restrictions:

- Staff cannot create admin users
- Staff cannot view audit log explorer (admin only)

## 6) Inventory Adjustment Flow

1. Admin/staff opens inventory adjustment form
2. Selects product and enters quantity delta
3. Adds reason code and optional note
4. Submits adjustment
5. System updates inventory and writes stock movement + audit event

## 7) Order Status State Machine

Allowed transitions:

- `pending` -> `confirmed`
- `confirmed` -> `packed`
- `packed` -> `ready`
- `ready` -> `dispatched`
- `dispatched` -> `completed`
- `pending` -> `cancelled`
- `confirmed` -> `cancelled` (only if operationally valid)

Disallowed transitions:

- Any backward transition from `completed`
- Skipping directly from `pending` to `completed`

## 8) Exception Flows

### Stock Conflict on Confirmation

1. Staff confirms order
2. Transaction detects insufficient stock
3. Confirmation is blocked with clear error
4. Staff updates quantity or adjusts stock and retries

### Invoice Generation Failure

1. Invoice generation job fails
2. Order remains unchanged
3. Error logged with request id
4. Staff/admin can retry generation

### Unauthorized Access Attempt

1. User attempts restricted page/API
2. Access denied (403)
3. Event logged for analysis

## 9) Mobile UX Priorities

- Sticky search bar in catalog
- Large quantity controls in cart
- Single-column checkout optimized for thumb reach
- Quick order status chips with clear color contrast
- Minimized typing through saved dealer defaults
