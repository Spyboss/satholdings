# 01 - Product Requirements Document (PRD)

Version: v1.0
Date: 2026-03-07
Status: Approved for build

## 1) Product Overview

DealerFlow is a mobile-first wholesale tyre ordering portal for SBK Tyre Distributors. The product digitizes phone and text based ordering into a structured, stock-aware web workflow while preserving private trade pricing.

### Business Objective

- Reduce order handling time and manual mistakes
- Enable dealers to self-serve catalog lookup and ordering
- Keep wholesale prices hidden from public visitors
- Maintain direct control over dealer onboarding and account access

## 2) Problem Statement

Current operations are heavily manual (calls, messages, and ad hoc records). This creates delays in stock visibility, inconsistent order capture, and limited traceability.

The portal will centralize catalog, pricing visibility, order capture, and invoice generation while staying simple enough for phone-first dealer usage.

## 3) Personas

### 3.1 Guest (Unauthenticated)

- Needs: browse products quickly and assess availability intent
- Restriction: cannot view prices or place orders

### 3.2 Dealer (Authenticated)

- Needs: search by tyre size, view wholesale prices, place orders from mobile, choose pickup or delivery
- Restriction: can only access own account/order history

### 3.3 Admin (Owner)

- Needs: full control over users, products, stock, price lists, orders, invoices, and audit logs

### 3.4 Staff

- Needs: operational support for stock updates and order processing
- Restriction: narrower permissions than admin

## 4) In-Scope (MVP)

1. Public catalog browsing with price masking
2. Dealer login and authenticated price visibility
3. Manual dealer account creation by admin only (public signup disabled)
4. Product search/filter by tyre size
5. Cart and checkout with `Pickup` or `Delivery`
6. Manual stock entry and automatic stock deduction on order confirmation
7. Invoice PDF generation and download
8. Admin + one staff account support
9. Order request workflow (no online payment)

## 5) Out of Scope (v1)

- Online card payments and payment gateway integration
- Discount engine and promotional bundles
- Advanced shipping rate engine by postcode/weight
- Public B2C checkout storefront
- Deep analytics dashboards beyond basic summaries

## 6) Functional Requirements

### Catalog and Search

- FR-001: Guests can view product catalog list and product details
- FR-002: Guest views must hide all prices and dealer-only actions
- FR-003: Dealers can view prices after login
- FR-004: Catalog supports search by tyre size and brand
- FR-005: Catalog supports stock indicator states (`In Stock`, `Low Stock`, `Out of Stock`)

### Authentication and Accounts

- FR-006: Public self-registration is disabled
- FR-007: Admin can create, activate, deactivate dealer accounts
- FR-008: Role-based access must support `admin`, `staff`, `dealer`
- FR-009: Dealers can log in, reset password, and manage profile basics

### Ordering

- FR-010: Dealers can add/remove/update quantity in cart
- FR-011: Checkout captures fulfillment method (`Pickup` or `Delivery`)
- FR-012: Order submission creates immutable order items snapshot
- FR-013: System prevents ordering above available stock unless admin override is enabled
- FR-014: Order lifecycle statuses: `pending`, `confirmed`, `packed`, `ready`, `dispatched`, `completed`, `cancelled`

### Inventory and Pricing

- FR-015: Admin/staff can create and update product records
- FR-016: Admin/staff can update stock manually
- FR-017: Stock is deducted automatically when order is confirmed
- FR-018: Stock adjustments create movement log entries with reason code
- FR-019: Price lists support effective date and active/inactive status

### Invoice and Documents

- FR-020: Confirmed orders can generate invoice PDFs
- FR-021: Invoice PDF must be downloadable by authorized users
- FR-022: Invoice files are stored in protected storage with access checks

### Operations and Audit

- FR-023: Critical actions are audit logged (who, what, when, context)
- FR-024: Admin can review order and inventory history
- FR-025: Basic reporting includes top buyers and top moving tyre sizes (summary level)

## 7) Non-Functional Requirements

- NFR-001: Mobile-first layout optimized for common dealer phone sizes
- NFR-002: p95 catalog response under 800ms for typical searches
- NFR-003: Core pages available at 99.5% uptime target
- NFR-004: All role-based data access enforced at DB policy level (RLS)
- NFR-005: Sensitive data encrypted in transit and at rest
- NFR-006: Production actions must be traceable through audit logs

## 8) UX Requirements

- Clear distinction between guest and dealer views
- Fast one-hand mobile interactions for ordering on warehouse floors
- Simple, high contrast stock states and order status chips
- Minimal checkout fields for speed

## 9) Data and Business Rules

- BIZ-001: Prices are visible only to authenticated dealers/admin/staff
- BIZ-002: Dealer accounts are created manually by admin
- BIZ-003: Stock is source of truth and decremented on order confirmation
- BIZ-004: Guest cannot access invoices or order data
- BIZ-005: Staff cannot modify admin permissions

## 10) Success Metrics

- 70% of wholesale orders submitted through portal by end of month 2
- 40% reduction in manual order clarification calls
- 90% of dealer orders completed on mobile without support
- Stock discrepancy incidents reduced by at least 30%

## 11) Acceptance Criteria (MVP Release)

1. Guest can browse products without seeing prices
2. Dealer login reveals price and enables ordering
3. Admin can manually create and disable dealer accounts
4. Tyre size search returns expected products within performance target
5. Checkout works with pickup/delivery selection
6. Order confirmation deducts stock and logs movement
7. Invoice PDF is generated and downloadable
8. Audit log captures critical admin/staff actions

## 12) Constraints and Dependencies

- Hosting must avoid Vercel and use Cloudflare Workers with OpenNext
- Backend services run on Supabase
- Initial catalog seed data is sourced from provided tyre list and manual cleanup
- Credentials shared in prior communication must be rotated before production

## 13) Post-MVP Candidates

- Emailing invoices automatically
- Dealer-specific price tiers and negotiated contract pricing
- Purchase order upload/import
- Advanced reporting and cohort analytics
- Optional online payment integration
