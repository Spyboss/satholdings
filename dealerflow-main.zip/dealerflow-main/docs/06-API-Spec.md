# 06 - API Specification

Version: v1.0
Date: 2026-03-07

## 1) API Conventions

- Base path: `/api/v1`
- Format: JSON (`application/json`)
- Auth: Supabase JWT in secure cookie or `Authorization: Bearer <token>`
- Time format: ISO 8601 UTC
- Pagination: `page`, `pageSize` (default 20, max 100)
- Idempotency: `Idempotency-Key` header for order submission endpoints

### Standard Success Envelope

```json
{
  "data": {},
  "meta": {
    "requestId": "req_123"
  }
}
```

### Standard Error Envelope

```json
{
  "error": {
    "code": "FORBIDDEN",
    "message": "You do not have permission to perform this action.",
    "details": null
  },
  "meta": {
    "requestId": "req_123"
  }
}
```

## 2) Auth and Session Endpoints

### `GET /api/v1/auth/me`

- Purpose: Return authenticated user profile and role context
- Auth: required
- Roles: `admin`, `staff`, `dealer`

Response:

```json
{
  "data": {
    "id": "uuid",
    "email": "dealer@example.com",
    "role": "dealer",
    "status": "active"
  }
}
```

## 3) Public Catalog Endpoints

### `GET /api/v1/catalog/products`

- Purpose: List products for guests and authenticated users
- Auth: optional
- Price behavior:
  - guest: price fields omitted
  - dealer/admin/staff: price fields included

Query params:

- `search` (size/brand/model)
- `brand`
- `size`
- `page`, `pageSize`

### `GET /api/v1/catalog/products/:productId`

- Purpose: Product detail
- Auth: optional
- Same price visibility rules as list endpoint

### `GET /api/v1/catalog/filters/sizes`

- Purpose: Return available size values for quick filtering
- Auth: optional

## 4) Dealer Endpoints

### `POST /api/v1/dealer/orders`

- Purpose: Submit a new order request
- Auth: required
- Roles: `dealer`

Request:

```json
{
  "fulfillmentMethod": "pickup",
  "deliveryAddress": null,
  "notes": "Call before dispatch",
  "items": [
    {
      "productId": "uuid",
      "quantity": 4
    }
  ]
}
```

Response:

```json
{
  "data": {
    "orderId": "uuid",
    "orderNumber": "ORD-20260307-001",
    "status": "pending"
  }
}
```

### `GET /api/v1/dealer/orders`

- Purpose: List orders belonging to current dealer
- Auth: required
- Roles: `dealer`

### `GET /api/v1/dealer/orders/:orderId`

- Purpose: Return dealer-visible order detail
- Auth: required
- Roles: `dealer`

### `GET /api/v1/dealer/orders/:orderId/invoice`

- Purpose: Get signed download URL or stream invoice file
- Auth: required
- Roles: `dealer`
- Condition: invoice must exist and order must belong to dealer

## 5) Admin and Staff Endpoints

### Dealer Management

#### `POST /api/v1/admin/dealers`

- Purpose: Create dealer account manually
- Auth: required
- Roles: `admin`

Request:

```json
{
  "email": "newdealer@example.com",
  "fullName": "Dealer Contact",
  "companyName": "Dealer Pty Ltd",
  "phone": "+61...",
  "address": {
    "line1": "...",
    "city": "...",
    "state": "VIC",
    "postcode": "3977",
    "country": "AU"
  }
}
```

#### `PATCH /api/v1/admin/dealers/:userId`

- Purpose: Activate/deactivate dealer and update profile
- Auth: required
- Roles: `admin`

### Product and Pricing

#### `POST /api/v1/admin/products`

- Roles: `admin`, `staff`
- Purpose: Create product

#### `PATCH /api/v1/admin/products/:productId`

- Roles: `admin`, `staff`
- Purpose: Update product

#### `POST /api/v1/admin/price-lists`

- Roles: `admin`
- Purpose: Create price list

#### `POST /api/v1/admin/price-lists/:priceListId/items`

- Roles: `admin`, `staff`
- Purpose: Upsert product prices

### Inventory

#### `POST /api/v1/admin/inventory/adjust`

- Roles: `admin`, `staff`
- Purpose: Manual stock adjustments with reason tracking

Request:

```json
{
  "productId": "uuid",
  "quantityDelta": 10,
  "reasonCode": "restock",
  "notes": "Supplier delivery"
}
```

### Order Operations

#### `GET /api/v1/admin/orders`

- Roles: `admin`, `staff`
- Purpose: Operational order list with filters by status/date/dealer

#### `POST /api/v1/admin/orders/:orderId/confirm`

- Roles: `admin`, `staff`
- Purpose: Confirm order and deduct stock atomically

#### `PATCH /api/v1/admin/orders/:orderId/status`

- Roles: `admin`, `staff`
- Purpose: Move order through lifecycle (`packed`, `ready`, `dispatched`, `completed`, `cancelled`)

### Invoice and Audit

#### `POST /api/v1/admin/orders/:orderId/invoice`

- Roles: `admin`, `staff`
- Purpose: Generate/re-generate invoice PDF

#### `GET /api/v1/admin/audit-logs`

- Roles: `admin`
- Purpose: Search audit events by actor/entity/action/date

## 6) HTTP Status Codes

- `200` OK
- `201` Created
- `400` Bad request / validation error
- `401` Unauthorized
- `403` Forbidden
- `404` Not found
- `409` Conflict (duplicate or stock conflict)
- `422` Unprocessable entity
- `429` Rate limited
- `500` Internal server error

## 7) Validation and Contract Rules

- All request payloads validated with Zod schemas
- Unknown keys rejected for write endpoints
- Quantity fields must be integers greater than zero
- Delivery address required when `fulfillmentMethod=delivery`
- Protected endpoints require role check before DB mutation

## 8) Versioning Policy

- Current: `v1`
- Breaking changes require path bump (`/api/v2`)
- Non-breaking additions can be released within same major version
