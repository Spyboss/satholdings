# 04 - Entity Relationship Diagram (ERD)

Version: v1.0
Date: 2026-03-07

## 1) Mermaid ERD

```mermaid
erDiagram
  users {
    uuid id PK
    uuid auth_user_id UK
    string email UK
    string full_name
    string role
    string status
    timestamptz created_at
    timestamptz updated_at
  }

  dealer_profiles {
    uuid id PK
    uuid user_id FK
    string company_name
    string phone
    string address_line1
    string city
    string state
    string postcode
    string country
    string default_fulfillment
    timestamptz created_at
    timestamptz updated_at
  }

  products {
    uuid id PK
    string sku UK
    string brand
    string model
    string size
    string load_rating
    string speed_rating
    string pattern
    boolean is_active
    timestamptz created_at
    timestamptz updated_at
  }

  inventory {
    uuid id PK
    uuid product_id FK
    string location_code
    int on_hand
    int reserved
    int reorder_level
    timestamptz updated_at
  }

  price_lists {
    uuid id PK
    string name
    string currency
    date effective_from
    date effective_to
    string status
    uuid created_by FK
    timestamptz created_at
  }

  price_list_items {
    uuid id PK
    uuid price_list_id FK
    uuid product_id FK
    numeric unit_price
    boolean gst_inclusive
    int min_qty
    timestamptz created_at
  }

  orders {
    uuid id PK
    string order_number UK
    uuid dealer_user_id FK
    uuid dealer_profile_id FK
    string status
    string fulfillment_method
    jsonb delivery_address
    numeric subtotal
    numeric gst_total
    numeric grand_total
    timestamptz requested_at
    timestamptz confirmed_at
    timestamptz completed_at
    timestamptz created_at
  }

  order_items {
    uuid id PK
    uuid order_id FK
    uuid product_id FK
    string sku_snapshot
    string size_snapshot
    string brand_snapshot
    numeric unit_price_snapshot
    int quantity
    numeric line_total
    timestamptz created_at
  }

  stock_movements {
    uuid id PK
    uuid product_id FK
    uuid order_item_id FK
    string movement_type
    int quantity
    string reason_code
    string reference_type
    uuid reference_id
    uuid performed_by FK
    timestamptz performed_at
  }

  invoices {
    uuid id PK
    uuid order_id FK
    string invoice_number UK
    string status
    string file_path
    timestamptz generated_at
    uuid generated_by FK
  }

  audit_logs {
    uuid id PK
    uuid actor_user_id FK
    string action
    string entity_type
    uuid entity_id
    jsonb metadata
    string ip_address
    string user_agent
    timestamptz created_at
  }

  users ||--o| dealer_profiles : has
  users ||--o{ orders : places
  users ||--o{ audit_logs : performs
  products ||--o{ inventory : tracked_in
  products ||--o{ price_list_items : priced_by
  products ||--o{ order_items : ordered_as
  products ||--o{ stock_movements : affects
  price_lists ||--o{ price_list_items : contains
  orders ||--o{ order_items : contains
  orders ||--o| invoices : generates
  order_items ||--o{ stock_movements : creates
```

## 2) Relationship Notes

- A `dealer_profile` exists only for users with role `dealer`
- `orders.dealer_user_id` links the order to the authenticated dealer user
- `order_items` store snapshots of product data so historical invoices remain stable
- `stock_movements` act as the inventory ledger and should be append-only
- `invoices` are one-to-one with orders in v1 (single invoice per order)

## 3) Cardinality and Integrity Rules

- Every `order_item` must belong to exactly one order
- Every stock deduction caused by an order item should reference `order_item_id`
- Active price determination uses active `price_list` + matching `price_list_item`
- `audit_logs` may include actor-less system events where needed
