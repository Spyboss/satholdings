# 05 - Data Dictionary

Version: v1.0
Date: 2026-03-07

## Conventions

- Primary keys are UUIDs (`gen_random_uuid()`)
- All timestamps are `timestamptz` in UTC
- Soft state is represented via status fields where needed
- RLS applies to business tables in production

## 1) `users`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Internal user id |
| auth_user_id | uuid | UNIQUE, NOT NULL | Maps to Supabase Auth user |
| email | citext | UNIQUE, NOT NULL | Login identity |
| full_name | text | NULL | Display name |
| role | text | NOT NULL, CHECK in (`admin`,`staff`,`dealer`) | Authorization role |
| status | text | NOT NULL, CHECK in (`active`,`inactive`) | Account state |
| created_at | timestamptz | NOT NULL default now() | Creation timestamp |
| updated_at | timestamptz | NOT NULL default now() | Last update timestamp |

Indexes:

- unique on `auth_user_id`
- unique on `email`
- btree on `role`, `status`

## 2) `dealer_profiles`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Dealer profile id |
| user_id | uuid | UNIQUE, FK -> users.id | Dealer user reference |
| company_name | text | NOT NULL | Business name |
| abn | text | NULL | Australian Business Number |
| phone | text | NULL | Dealer contact number |
| address_line1 | text | NULL | Primary address line |
| address_line2 | text | NULL | Secondary address line |
| city | text | NULL | City/suburb |
| state | text | NULL | State/region |
| postcode | text | NULL | Postal code |
| country | text | NOT NULL default 'AU' | Country code |
| default_fulfillment | text | CHECK in (`pickup`,`delivery`) | Default checkout option |
| created_at | timestamptz | NOT NULL default now() | Creation timestamp |
| updated_at | timestamptz | NOT NULL default now() | Last update timestamp |

## 3) `products`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Product id |
| sku | text | UNIQUE, NOT NULL | Internal SKU |
| brand | text | NOT NULL | Tyre brand |
| model | text | NULL | Model name |
| size | text | NOT NULL | Tyre size token (example `225/45R18`) |
| load_rating | text | NULL | Load index/rating |
| speed_rating | text | NULL | Speed symbol |
| pattern | text | NULL | Pattern/tread name |
| description | text | NULL | Optional details |
| image_path | text | NULL | Storage key for product image |
| is_active | boolean | NOT NULL default true | Visibility control |
| created_at | timestamptz | NOT NULL default now() | Creation timestamp |
| updated_at | timestamptz | NOT NULL default now() | Last update timestamp |

Indexes:

- unique on `sku`
- btree on `brand`
- btree on `size`
- optional trigram index for fuzzy size search

## 4) `inventory`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Inventory row id |
| product_id | uuid | FK -> products.id, NOT NULL | Product reference |
| location_code | text | NOT NULL default `MAIN` | Warehouse/location key |
| on_hand | integer | NOT NULL, CHECK >= 0 | Physical stock count |
| reserved | integer | NOT NULL default 0, CHECK >= 0 | Reserved for open orders |
| reorder_level | integer | NOT NULL default 0 | Restock threshold |
| updated_at | timestamptz | NOT NULL default now() | Last stock update |

Composite constraints:

- UNIQUE (`product_id`, `location_code`)

## 5) `price_lists`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Price list id |
| name | text | NOT NULL | Human readable name |
| currency | text | NOT NULL default `AUD` | Currency code |
| effective_from | date | NOT NULL | Start date |
| effective_to | date | NULL | End date (open-ended if null) |
| status | text | NOT NULL, CHECK in (`draft`,`active`,`archived`) | Lifecycle state |
| created_by | uuid | FK -> users.id | Creator |
| created_at | timestamptz | NOT NULL default now() | Creation timestamp |
| updated_at | timestamptz | NOT NULL default now() | Last update timestamp |

## 6) `price_list_items`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Price line id |
| price_list_id | uuid | FK -> price_lists.id, NOT NULL | Parent list |
| product_id | uuid | FK -> products.id, NOT NULL | Product reference |
| unit_price | numeric(10,2) | NOT NULL, CHECK >= 0 | Unit sell price |
| gst_inclusive | boolean | NOT NULL default true | Tax inclusion flag |
| min_qty | integer | NOT NULL default 1, CHECK > 0 | Tier threshold |
| created_at | timestamptz | NOT NULL default now() | Creation timestamp |
| updated_at | timestamptz | NOT NULL default now() | Last update timestamp |

Composite constraints:

- UNIQUE (`price_list_id`, `product_id`, `min_qty`)

## 7) `orders`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Order id |
| order_number | text | UNIQUE, NOT NULL | Human order identifier |
| dealer_user_id | uuid | FK -> users.id, NOT NULL | Ordering dealer |
| dealer_profile_id | uuid | FK -> dealer_profiles.id, NOT NULL | Dealer profile snapshot link |
| status | text | NOT NULL, CHECK in (`pending`,`confirmed`,`packed`,`ready`,`dispatched`,`completed`,`cancelled`) | Order state |
| fulfillment_method | text | NOT NULL, CHECK in (`pickup`,`delivery`) | Fulfillment option |
| delivery_address | jsonb | NULL | Required when delivery selected |
| notes | text | NULL | Dealer/admin notes |
| subtotal | numeric(12,2) | NOT NULL default 0 | Amount before tax |
| gst_total | numeric(12,2) | NOT NULL default 0 | Tax total |
| grand_total | numeric(12,2) | NOT NULL default 0 | Final amount |
| requested_at | timestamptz | NOT NULL default now() | Submission time |
| confirmed_at | timestamptz | NULL | Confirmation timestamp |
| completed_at | timestamptz | NULL | Completion timestamp |
| created_at | timestamptz | NOT NULL default now() | Creation timestamp |
| updated_at | timestamptz | NOT NULL default now() | Last update timestamp |

Indexes:

- unique on `order_number`
- btree on `dealer_user_id`, `status`, `created_at`

## 8) `order_items`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Order item id |
| order_id | uuid | FK -> orders.id, NOT NULL | Parent order |
| product_id | uuid | FK -> products.id, NOT NULL | Product reference |
| sku_snapshot | text | NOT NULL | SKU at order time |
| size_snapshot | text | NOT NULL | Size at order time |
| brand_snapshot | text | NOT NULL | Brand at order time |
| unit_price_snapshot | numeric(10,2) | NOT NULL | Price at order time |
| quantity | integer | NOT NULL, CHECK > 0 | Ordered units |
| line_total | numeric(12,2) | NOT NULL | Extended line amount |
| created_at | timestamptz | NOT NULL default now() | Creation timestamp |

Indexes:

- btree on `order_id`
- btree on `product_id`

## 9) `stock_movements`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Stock movement id |
| product_id | uuid | FK -> products.id, NOT NULL | Affected product |
| order_item_id | uuid | FK -> order_items.id, NULL | Related order line |
| movement_type | text | NOT NULL, CHECK in (`in`,`out`,`adjust`) | Movement category |
| quantity | integer | NOT NULL, CHECK <> 0 | Signed delta |
| reason_code | text | NOT NULL | Reason (`order_confirmed`,`manual_adjustment`,`restock`) |
| reference_type | text | NOT NULL | Reference domain (`order`,`manual`,`system`) |
| reference_id | uuid | NULL | Domain object id |
| performed_by | uuid | FK -> users.id, NULL | Actor |
| performed_at | timestamptz | NOT NULL default now() | Event timestamp |
| notes | text | NULL | Optional explanation |

Indexes:

- btree on `product_id`, `performed_at`
- btree on `order_item_id`

## 10) `invoices`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Invoice id |
| order_id | uuid | UNIQUE, FK -> orders.id, NOT NULL | Parent order |
| invoice_number | text | UNIQUE, NOT NULL | Invoice reference |
| status | text | NOT NULL, CHECK in (`draft`,`issued`,`void`) | Invoice state |
| file_path | text | NOT NULL | Storage object key |
| file_size_bytes | bigint | NULL | Artifact size |
| generated_at | timestamptz | NOT NULL default now() | Generation time |
| generated_by | uuid | FK -> users.id, NULL | Actor |

## 11) `audit_logs`

| Field | Type | Constraints | Description |
|---|---|---|---|
| id | uuid | PK | Audit row id |
| actor_user_id | uuid | FK -> users.id, NULL | Action initiator |
| action | text | NOT NULL | Verb (`dealer.create`,`stock.adjust`) |
| entity_type | text | NOT NULL | Domain type |
| entity_id | uuid | NULL | Domain id |
| metadata | jsonb | NOT NULL default '{}' | Extra context payload |
| ip_address | inet | NULL | Request IP |
| user_agent | text | NULL | Request user agent |
| created_at | timestamptz | NOT NULL default now() | Action timestamp |

Indexes:

- btree on `actor_user_id`
- btree on (`entity_type`, `entity_id`)
- btree on `created_at`
