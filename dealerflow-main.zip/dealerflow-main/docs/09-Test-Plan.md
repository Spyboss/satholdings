# 09 - Test Plan

Version: v1.0
Date: 2026-03-07

## 1) Test Objectives

- Verify all MVP acceptance criteria from PRD
- Confirm price privacy and RBAC enforcement
- Validate stock consistency across order lifecycle
- Ensure mobile-first usability for dealer workflows

## 2) Scope

In scope:

- Auth and role-based access
- Catalog/search and price masking
- Cart/checkout and order lifecycle
- Inventory adjustments and stock movement logging
- Invoice generation and download access control
- Core admin/staff operations

Out of scope:

- Payment gateway scenarios (not part of v1)
- Advanced shipping pricing calculations

## 3) Test Levels and Tooling

- Unit tests: business logic, validators, utility functions
- Integration tests: API routes + DB transactions + RLS behavior
- End-to-end tests: key user journeys (guest, dealer, staff, admin)
- UAT: business walkthrough with real-like catalog data

Suggested tooling:

- Unit/Integration: Vitest
- E2E: Playwright
- API contract checks: schema assertions against Zod

## 4) Test Environments

- Local: developer machines with seeded sample data
- Staging: Cloudflare preview + Supabase staging project
- Production: post-deploy smoke checks only

Environment parity requirements:

- Same schema migration version
- Same RLS policy set
- Representative product and stock data

## 5) Core Functional Test Scenarios

| ID | Scenario | Expected Result |
|---|---|---|
| TC-001 | Guest opens catalog | Products visible, prices hidden |
| TC-002 | Guest calls price API path directly | Price fields not returned / access blocked |
| TC-003 | Dealer login success | Dealer session active and role resolved |
| TC-004 | Dealer search by size | Correct results returned within target latency |
| TC-005 | Dealer submits pickup order | Pending order created with correct totals |
| TC-006 | Dealer submits delivery order without address | Validation error |
| TC-007 | Staff confirms order with stock available | Status updated and stock deducted |
| TC-008 | Staff confirms order with insufficient stock | Confirmation blocked, no stock change |
| TC-009 | Admin creates dealer account | New dealer user and profile created |
| TC-010 | Staff attempts dealer account creation | Forbidden |
| TC-011 | Invoice generation | PDF created and stored, downloadable by authorized user |
| TC-012 | Dealer accesses another dealer order | Forbidden or not found |
| TC-013 | Inventory manual adjustment | Inventory and stock movement updated atomically |
| TC-014 | Critical admin action | Audit log entry recorded |

## 6) Security Test Cases

- RBAC matrix verification for every protected route
- RLS enforcement checks using direct SQL/API access patterns
- Injection payload rejection on all write endpoints
- Session expiration and re-auth behavior
- Signed URL expiry validation for invoice downloads

## 7) Performance and Reliability Tests

- Catalog search p95 under 800ms with representative dataset
- Order confirmation transaction under concurrent submissions
- Basic soak test for repeated catalog and order history requests
- Error path stability for invoice generation retries

## 8) UAT Checklist

- Admin can onboard and disable dealers
- Dealer can complete full order flow on mobile
- Staff can process and update order statuses
- Stock and order records remain consistent after operational actions
- Invoice generation works for completed/eligible orders
- No public exposure of trade pricing

## 9) Defect Severity Model

- Sev-1: Data leak, security break, or blocking checkout issue
- Sev-2: Major feature impairment with workaround
- Sev-3: Minor usability or non-critical defect

Release gate:

- Zero open Sev-1 defects
- Zero open Sev-2 defects in MVP-critical paths

## 10) Test Exit Criteria

- All PRD acceptance criteria passed
- Core E2E suite green in staging
- RBAC and RLS tests passing
- UAT sign-off recorded
- Deployment smoke tests passed
