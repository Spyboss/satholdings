# 11 - Risks, Assumptions, and Open Questions

Version: v1.0
Date: 2026-03-07

## 1) Assumptions

1. The portal remains wholesale-only in MVP
2. Dealer accounts are always manually provisioned by admin
3. Single-currency pricing (`AUD`) for v1
4. One primary stock location is sufficient for MVP
5. Delivery cost calculation is not dynamic in v1 (fulfillment option only)
6. Invoice email sending is optional and can be deferred

## 2) Risk Register

| ID | Risk | Impact | Likelihood | Mitigation | Owner |
|---|---|---|---|---|---|
| R-001 | Previously shared credentials are compromised | high | high | Rotate all credentials before non-local deploy; enforce secrets manager usage | Admin/Engineering |
| R-002 | Seed catalog data quality issues | medium | high | Add import validation and manual review pass before go-live | Product/Operations |
| R-003 | Price leakage through API or DB policy gaps | high | medium | Multi-layer gating (UI/API/RLS) and dedicated security tests | Engineering |
| R-004 | Stock mismatch under concurrent confirmations | high | medium | Transactional stock updates with locking and conflict handling | Engineering |
| R-005 | Cloudflare runtime limitations affect PDF generation | medium | medium | Validate early; prepare fallback generation path | Engineering |
| R-006 | Dealer adoption slower than expected | medium | medium | Mobile-first UX, onboarding walkthrough, support window | Business |
| R-007 | Operational misuse of status transitions | medium | medium | Restrict transitions by state machine and role, with audit logs | Operations |

## 3) Risk Response Triggers

- Security trigger: any suspicious login/admin action -> immediate key rotation + account review
- Data trigger: repeated stock discrepancy > threshold -> freeze confirmations and investigate
- Runtime trigger: invoice generation error rate above threshold -> switch to fallback path and queue retries

## 4) Open Questions

1. Should delivery orders include a fixed delivery fee in v1, or remain off-invoice?
2. Is invoice numbering format required to match an existing accounting pattern?
3. Should staff be allowed to edit active price lists, or admin-only after launch?
4. Do cancelled orders always restore reserved/deducted stock automatically?

## 5) Decision Log (Current)

| Decision ID | Decision | Status | Date |
|---|---|---|---|
| D-001 | Hosting uses Cloudflare Workers + OpenNext, not Vercel | approved | 2026-03-07 |
| D-002 | Backend platform is Supabase | approved | 2026-03-07 |
| D-003 | Checkout model is order request only (no online payments) | approved | 2026-03-07 |
| D-004 | Dealer signup is disabled; admin creates dealer accounts | approved | 2026-03-07 |
| D-005 | Guests can browse products but cannot see prices | approved | 2026-03-07 |

## 6) Change Management Rules

- Any scope change affecting timeline or architecture must update PRD and Full Plan
- Security-impacting changes require explicit review before merge
- New external integrations must be recorded with risk and rollback strategy
