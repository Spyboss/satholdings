# 02 - Full Delivery Plan

Version: v1.0
Date: 2026-03-07
Status: Ready for execution

## 1) Delivery Strategy

The MVP will be delivered in seven phases with strict phase exit gates. Each phase produces deployable increments and documentation updates.

## 2) Phase Breakdown

### Phase 0 - Discovery Lock and Sign-Off

Scope:

- Confirm product goals, constraints, and release acceptance criteria
- Finalize role model (`admin`, `staff`, `dealer`)
- Freeze MVP boundaries and non-goals

Deliverables:

- Finalized PRD and architecture docs
- Initial risk register and mitigation owner assignment

Exit Criteria:

- All open requirement blockers resolved
- Stakeholder sign-off recorded

### Phase 1 - Data Model and Foundations

Scope:

- Define Postgres schema and migrations via Drizzle
- Create tables, constraints, indexes, and RLS scaffolding
- Build seed ingestion pipeline for initial product and pricing records

Deliverables:

- Versioned migrations
- Seed script for baseline catalog import
- ERD and data dictionary revision

Exit Criteria:

- Schema migrates cleanly in dev/staging
- Seed data loads with validation and de-duplication

### Phase 2 - Auth, RBAC, and Dealer Management

Scope:

- Configure Supabase Auth with public signup disabled
- Implement role assignment and policy enforcement
- Build admin/staff user management screens

Deliverables:

- Working sign-in and password reset
- Admin-only dealer creation workflow
- User activation/deactivation controls

Exit Criteria:

- Role policies verified with access matrix tests
- Unauthorized route and API access blocked

### Phase 3 - Catalog and Search

Scope:

- Build product list and detail pages
- Implement search by tyre size and brand
- Enforce guest price masking and dealer price reveal

Deliverables:

- Mobile-optimized browse and search UX
- Visibility gating at UI + API + DB layers

Exit Criteria:

- Guest cannot retrieve prices via API or UI
- Dealer search response meets p95 performance target

### Phase 4 - Cart, Checkout, and Order Lifecycle

Scope:

- Cart item management and checkout flow
- Fulfillment method capture (`Pickup`, `Delivery`)
- Order state machine implementation
- Stock deduction on order confirmation with transaction safety

Deliverables:

- Order creation APIs and pages
- Inventory movement logs from order actions
- Operational order management for admin/staff

Exit Criteria:

- Stock remains consistent under concurrent order tests
- Order status transitions follow allowed rules only

### Phase 5 - Invoices, History, and Audit Logs

Scope:

- Generate invoice PDFs server-side
- Store and secure invoice access in Supabase Storage
- Add order history pages and audit trail views

Deliverables:

- Downloadable invoice artifacts
- Audit event capture for critical operations

Exit Criteria:

- Invoices generated for confirmed/completed orders
- Audit logs include actor, action, timestamp, and target

### Phase 6 - QA, UAT, Deploy, and Handover

Scope:

- Execute test plan and UAT checklist
- Deploy to Cloudflare Workers production
- Complete runbook and handover package

Deliverables:

- Signed UAT report
- Production deployment and smoke test report
- Operations runbook and support notes

Exit Criteria:

- MVP acceptance criteria fully passed
- Monitoring and rollback process validated

## 3) Milestones and Target Sequence

- M1: Requirements and architecture frozen (end Phase 0)
- M2: Data + auth baseline complete (end Phase 2)
- M3: Orderable catalog live in staging (end Phase 4)
- M4: Invoice and audit-ready release candidate (end Phase 5)
- M5: Production launch and handover (end Phase 6)

## 4) Dependency Map

1. Data model must complete before role policies and API contracts
2. RBAC must complete before price visibility gating is considered secure
3. Order lifecycle must complete before invoice generation
4. QA and UAT require stable staging environment and realistic seed data

## 5) Estimated Timeline (Indicative)

- Phase 0: 2-3 days
- Phase 1: 4-6 days
- Phase 2: 4-6 days
- Phase 3: 4-5 days
- Phase 4: 6-8 days
- Phase 5: 3-5 days
- Phase 6: 3-4 days

Total: approximately 4-6 weeks including review cycles.

## 6) Definition of Done (Per Phase)

- Feature code merged with peer review complete
- Relevant documentation updated
- Tests added or updated with passing status
- Security and permission checks validated
- Stakeholder demo completed for phase outcomes

## 7) Delivery Risks Tied to Plan

- Imported seed data quality may require manual normalization
- Cloudflare runtime compatibility for PDF generation must be validated early
- Role and policy gaps can create data leakage risk if not tested deeply

Mitigation:

- Run schema and PDF compatibility spike in Phase 1
- Build automated authorization tests starting Phase 2
- Include UAT scenarios for guest/dealer price visibility boundaries

## 8) Handover Package Checklist

- Production environment variables inventory
- Deployment and rollback runbook
- Admin/staff operational guide
- Known issues and backlog recommendations
- Credential rotation confirmation log
