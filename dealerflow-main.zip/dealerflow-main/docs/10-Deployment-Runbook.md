# 10 - Deployment Runbook

Version: v1.0
Date: 2026-03-07

## 1) Purpose

This runbook defines how to deploy DealerFlow to Cloudflare Workers (OpenNext) with Supabase backend services, including migration, verification, and rollback procedures.

## 2) Prerequisites

- Cloudflare account with Workers access
- Supabase project(s): staging and production
- Domain managed in Cloudflare DNS
- CI/CD access to repository
- Maintainer access to secrets management

## 3) Environment Variables

| Variable | Required | Scope | Notes |
|---|---|---|---|
| NEXT_PUBLIC_SUPABASE_URL | yes | client/server | Supabase project URL |
| NEXT_PUBLIC_SUPABASE_ANON_KEY | yes | client/server | Public anon key |
| SUPABASE_SERVICE_ROLE_KEY | yes | server only | Never expose to client |
| DATABASE_URL | yes | server only | Postgres connection string for Drizzle |
| SUPABASE_INVOICE_BUCKET | yes | server only | Private storage bucket |
| SUPABASE_PRODUCT_IMAGE_BUCKET | yes | server only | Product image bucket |
| APP_BASE_URL | yes | server | Public application URL |
| INVOICE_NUMBER_PREFIX | yes | server | Example `INV` |
| RATE_LIMIT_SECRET | recommended | server | API abuse protection |
| LOG_LEVEL | recommended | server | `info`/`warn`/`error` |

## 4) One-Time Setup

### Supabase

1. Create project and configure region close to AU users
2. Enable Auth email/password and disable public signup
3. Create storage buckets:
   - `product-images` (read controlled)
   - `invoices` (private)
4. Apply base migrations and RLS policies
5. Seed initial product and pricing dataset

### Cloudflare Workers

1. Configure Worker deployment target connected to repository or CI
2. Configure framework preset for Next.js compatibility build
3. Set build command and output directory per project scripts
4. Configure environment variables for preview and production
5. Attach custom domain and verify TLS

## 5) Recommended Build/Deploy Pipeline

1. Install dependencies
2. Run lint and tests
3. Generate/apply DB migrations for target environment
4. Build Next.js app with OpenNext adapter
5. Deploy preview (on PR) or production (on main)

Example CI stages:

- `validate`: lint, typecheck, unit tests
- `integration`: API and auth integration tests
- `build`: framework compatibility build
- `deploy`: Cloudflare Workers deployment

## 6) Release Procedure (Production)

1. Confirm staging is green and UAT signed off
2. Freeze release branch and tag candidate
3. Backup production database snapshot
4. Apply production migrations
5. Deploy app to Cloudflare Workers production
6. Run post-deploy smoke checks
7. Announce release and monitor metrics

## 7) Smoke Test Checklist

- Home page and catalog load
- Guest cannot see prices
- Dealer login works
- Dealer can place order request
- Staff/admin can confirm order and update status
- Stock deduction recorded correctly
- Invoice generation and download works

## 8) Rollback Procedure

### App Rollback

1. Redeploy previous known-good Worker build
2. Validate smoke tests on rolled-back version

### Database Rollback

- Prefer forward-fix migrations
- If critical, restore from backup snapshot per incident protocol
- Communicate data impact clearly before restore actions

## 9) Monitoring and Alerting

- Application errors and exception rates
- Auth failure spikes
- API latency and 5xx trend
- Storage failures for invoice generation/download
- Inventory transaction failure count

## 10) Operational Security Checks

- Verify service keys exist only in server-side scopes
- Confirm signed URL expiry for invoice access
- Review recent audit logs for unexpected admin actions
- Rotate exposed credentials from prior shared artifacts before launch

## 11) Post-Deployment Handover

- Share admin/staff quick-start guide
- Record release notes and known limitations
- Confirm backup and recovery owner assignment
- Schedule first-week hypercare review
