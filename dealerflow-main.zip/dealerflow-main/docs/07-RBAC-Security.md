# 07 - RBAC and Security

Version: v1.0
Date: 2026-03-07

## 1) Role Definitions

- `admin`: Full control across users, catalog, inventory, orders, pricing, invoices, and audit logs
- `staff`: Operational role for products, stock, orders, and invoice generation
- `dealer`: Can view dealer pricing, place and track own orders, and download own invoices
- `guest`: Unauthenticated visitor; catalog browsing only without prices

## 2) Permission Matrix

| Capability | guest | dealer | staff | admin |
|---|---|---|---|---|
| View catalog products | yes | yes | yes | yes |
| View prices | no | yes | yes | yes |
| Place order request | no | yes | no | yes |
| View own order history | no | yes | no | yes |
| View all orders | no | no | yes | yes |
| Update order status | no | no | yes | yes |
| Confirm order (stock deduct) | no | no | yes | yes |
| Manage inventory adjustments | no | no | yes | yes |
| Manage products | no | no | yes | yes |
| Manage price lists | no | no | limited | yes |
| Create/disable dealer accounts | no | no | no | yes |
| Access audit logs | no | no | no | yes |

## 3) Authorization Model

- Route-level guard: block unauthorized role access early
- Service-level guard: re-check role before mutation
- Database-level guard (RLS): final enforcement boundary
- Response-level guard: redact fields not allowed for role

## 4) RLS Policy Principles

### `users`

- Admin can read/write all app users
- Staff can read limited user details needed for operations
- Dealer can read own user row only

### `dealer_profiles`

- Admin full access
- Staff read-only unless explicitly allowed by policy
- Dealer can read/update own profile basics

### `products`

- Read allowed to all for active products
- Write restricted to staff/admin

### `price_lists` and `price_list_items`

- Guest denied
- Dealer read current active pricing only
- Staff/admin manage pricing entities

### `orders` and `order_items`

- Dealer can access only rows with own `dealer_user_id`
- Staff/admin can access all
- Guest denied

### `stock_movements`, `audit_logs`

- Staff/admin write movement logs through controlled APIs
- Dealer and guest denied direct access
- Audit logs readable by admin only

## 5) Security Controls

### Identity and Access

- Public signup disabled
- Dealer users provisioned manually by admin
- Account status check (`active`) required on each protected action
- Role changes audited and limited to admin

### Secrets and Credentials

- Store runtime secrets in Cloudflare/Supabase secret stores
- Never expose service role keys to browser bundles
- Enforce key rotation cadence and access logging

### Immediate Action Item

- Rotate all credentials that were shared in previous chat exports before any non-local deployment

### Input and API Hardening

- Strict Zod validation on all inputs
- Reject unknown payload keys for mutation routes
- Enforce request size limits for APIs and uploads
- Apply rate limits and bot checks on auth and write endpoints

### Data Protection

- TLS enforced end-to-end
- Postgres encryption at rest (managed by Supabase)
- Storage bucket access by signed URL only
- Short-lived invoice download links

### Monitoring and Audit

- Structured logs with request id and actor id
- Audit events for: user creation/disable, price changes, stock adjustments, order confirmations, invoice generation
- Alerting on repeated auth failures and privilege escalation attempts

## 6) Audit Event Minimum Schema

- `actor_user_id`
- `action`
- `entity_type`
- `entity_id`
- `metadata` (before/after diff where applicable)
- `ip_address`
- `user_agent`
- `created_at`

## 7) Security Testing Requirements

- Guest cannot fetch prices through direct API calls
- Dealer cannot access another dealer's orders/invoices
- Staff cannot perform admin-only user management
- RLS bypass attempts fail for all restricted tables
- Injection payloads rejected by validation layer

## 8) Incident Response Basics

- Severity-based incident levels (SEV-1 to SEV-3)
- Immediate containment: disable affected keys/users
- Forensics from audit logs + platform logs
- Post-incident review with corrective action tracking
